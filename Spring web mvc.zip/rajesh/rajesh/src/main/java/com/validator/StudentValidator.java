package com.validator;

import com.pojo.student.Student;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Pattern;

@Component
public class StudentValidator implements Validator {
    private static final String NAME_PATTERN = "^[A-Z][a-zA-Z\\s]*$";
    private static final String MOBILE_PATTERN = "[789]\\d{9}";

    @Override
    public boolean supports(Class<?> clazz) {
        return Student.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Student stu = (Student) target;
        String sname = stu.getSname();
        Long smobile = stu.getSmobile();

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sname", "student.sname.empty");

        if (sname != null && !Pattern.matches(NAME_PATTERN, sname)) {
            errors.rejectValue("sname", "student.sname.invalid");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "smobile", "student.smobile.empty");
        if (smobile != null && !Pattern.matches(MOBILE_PATTERN, String.valueOf(smobile))) {
            errors.rejectValue("smobile", "student.smobile.invalid");
        }
    }
}
