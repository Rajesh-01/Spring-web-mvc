package com.selenium.SN.controller;

import com.pojo.student.Student;
import com.serviceStudent.StudentService;
import com.student.DAO.StudentDao;
import com.validator.StudentValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//presentation layer
@Controller
public class StudentController {
    @Autowired
    StudentValidator studentValidator;
//    @Autowired
//    private StudentDao StudentDao;
    @Autowired
    private StudentService studentService;

    @RequestMapping(value = "/student")
    public String showStudent(Model model, @RequestParam("id") int id) {
       int size = studentService.countRow().size();
        int i = size % 5;
        if (i == 0) {
            size /= 5;
        } else {
            size = (size / 5) + 1;
        }
        model.addAttribute("size", size);

        List<Student> studenlist = studentService.loadStudent(id * 5);
        for (Student tempstudent : studenlist) {
            System.out.println(tempstudent);
        }

        model.addAttribute("students", studenlist);

        return "sList";
    }

    @RequestMapping("/addpage")
    public String addStudent(Model model) {
        Student student = new Student();
        //model.addAttribute("student",new StudentDTO());
        model.addAttribute("student", new Student());
        return "addStudent";
    }

    @RequestMapping("/saveStudent")
    public String saveStudent(@ModelAttribute @Validated Student student, BindingResult result) {


        studentValidator.validate(student, result);
            if(result.hasErrors()){
                return "addStudent";
            }
        if(student.getId()==0)
        {
            studentService.saveStudent(student);
            return "redirect:/byId?id=0";
        }
        else {
            studentService.update(student);
            return "redirect:/singleRecord?id="+student.getId();
        }
    }


    @RequestMapping("/updateStudent")
    public String updateStudent(@RequestParam("userId") int id, Model model) {
        System.out.println("locking the id " + id);

        Student theStudent = studentService.getStudent(id);

        System.out.println(theStudent);
        model.addAttribute("student", theStudent);

        return "addStudent";
    }


    @RequestMapping("/deleteStudent")

    public String DeleteStudent(@RequestParam("userId") int id) {

        studentService.deleteStudent(id);
        return "redirect:/byId?id=0";
    }


    @RequestMapping(value = "/byId")
    public String byId(Model model, @RequestParam("id") int id) {
        int size = studentService.countRow().size();

        int i = size % 5;
        if (i == 0) {
            size /= 5;
        } else {
            size = (size / 5) + 1;
        }
        model.addAttribute("size", size);

        List<Student> studenlist = studentService.loadStudent(id * 5);
        for (Student tempstudent : studenlist) {
            System.out.println(tempstudent);
        }

        model.addAttribute("students", studenlist);

        return "byId";
    }

    @GetMapping("/singleRecord")
    public String showSingleRecord(@RequestParam("id") int id, Model model) {

        model.addAttribute("singleRecord", studentService.getStudent(id));
        model.addAttribute("id", id);
        return "singleRecord";
    }


}

