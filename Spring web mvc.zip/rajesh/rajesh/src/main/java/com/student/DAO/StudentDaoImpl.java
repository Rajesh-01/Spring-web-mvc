package com.student.DAO;

import RowMapper.StudentRowMapper;
import com.pojo.student.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Student> loadStudent(int size) {
        String sql = "select * from student limit 5 offset  "+size;
        List<Student> query = jdbcTemplate.query(sql, new StudentRowMapper());
        return query;
    }


    @Override
    public void saveStudent(Student student) {
        //write the logic to save the student databsase;
        Object[] sqlparameter = {student.getSname(), student.getSmobile(), student.getCountry()};
        String sql = "insert into student(sname,smobile,country) values(?,?,?)";
        jdbcTemplate.update(sql, sqlparameter);
        System.out.println("1 recorded update");

    }

    @Override
    public Student getStudent(int id) {
        String sql = "SELECT * FROM student WHERE id=?";
        return jdbcTemplate.queryForObject(sql, new StudentRowMapper(), id);
    }

    @Override
    public void update(Student student) {
        String sql = "update student set sname=?,smobile=?,country=? where id=?";
        jdbcTemplate.update(sql, student.getSname(), student.getSmobile(), student.getCountry(), student.getId());
        System.out.println("1 recorded updated");
    }

    @Override
    public void deleteStudent(int id)
    {
        String sql="delete from student where id=?";
        jdbcTemplate.update(sql,id);

    }

    @Override
    public List<Student> countRow() {
        String sql = "select * from student ";
        List<Student> query = jdbcTemplate.query(sql, new StudentRowMapper());
        return query;
    }



}
