package com.pojo.student;

public class Student {
    private int id;
    private String sname;
    private long smobile;
    private String country;
//id | Sname  | Smobile    | country


    public int getId()
    {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public long getSmobile() {
        return smobile;
    }

    public void setSmobile(long smobile) {
        this.smobile = smobile;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", Sname='" + sname + '\'' + ", Smobile=" + smobile + ", country='" + country + '\'' + '}';
    }
}
