package com.serviceStudent;

import com.pojo.student.Student;
import com.student.DAO.StudentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class studentServiceImpl implements StudentService
{
    @Autowired
    private StudentDao StudentDao;
    @Override
    public List<Student> loadStudent(int size) {
        return StudentDao.loadStudent(size);
    }

    @Override
    public void saveStudent(Student student) {
        StudentDao.saveStudent(student);
    }

    @Override
    public Student getStudent(int id) {
        return StudentDao.getStudent(id);
    }

    @Override
    public void update(Student student) {
        StudentDao.update(student);
    }

    @Override
    public void deleteStudent(int id) {
        StudentDao.deleteStudent(id);
    }

    @Override
    public List<Student> countRow() {
        return StudentDao.countRow();
    }
}
