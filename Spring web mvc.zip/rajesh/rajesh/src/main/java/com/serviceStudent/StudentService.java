package com.serviceStudent;

import com.pojo.student.Student;

import java.util.List;

public interface StudentService
{
    List<Student> loadStudent(int size);
    void saveStudent(Student student);
    Student getStudent(int id);
    void update(Student student);
    void deleteStudent(int id);

    List<Student> countRow();
}
